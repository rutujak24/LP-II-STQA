<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Calculator{
    
    /**
     * 
     * @assert (0, 0) == 0
     * @assert (1, 0) == 1
     * @assert (0, 1) == 1
     * @assert (1, 1) == 2  
     */
public function add($a,$b)
{  
    return $a+$b;
    
    
}

}
?>