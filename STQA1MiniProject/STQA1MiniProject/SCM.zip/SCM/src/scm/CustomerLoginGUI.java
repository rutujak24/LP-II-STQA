package scm;

import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Vector;

public class CustomerLoginGUI implements ActionListener {

	JFrame jFrame;
	
	JButton jButtonBack, jButtonBack2, jButtonLogin, jButtonOrder;
	JTextField jTextFieldUsername, jTextFieldPassword;
	JRadioButton[] jRadioButtons;
	ButtonGroup buttonGroup;
	
	String passwordFromDB;
	String gender;
	String email;
	
	int selectedBranchIndex;
	
	CustomerLoginGUI(){
		loginAsCustomer();
	}
	
	public void loginAsCustomer() {
		
		jFrame = new JFrame();
		jFrame.setSize(1500,1500);
		jFrame.setTitle("Customer Login");
		jFrame.setLayout(null);  
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		jButtonBack = new JButton("<");
		jButtonBack.setBounds(10, 10, 50, 50);
		jButtonBack.addActionListener(this);
		jFrame.add(jButtonBack);
		
		JLabel jLabel0=new JLabel("Username");
		jLabel0.setBounds(100, 100, 200, 50);
		jFrame.add(jLabel0);
		
		jTextFieldUsername=new JTextField();
		jTextFieldUsername.setBounds(300, 100, 200, 50); //x,y,width,height
		jFrame.add(jTextFieldUsername);

		JLabel jLabel1=new JLabel("Password");
		jLabel1.setBounds(100, 160, 200, 50);
		jFrame.add(jLabel1);
		
		jTextFieldPassword=new JTextField();
		jTextFieldPassword.setBounds(300, 160, 200, 50); //x,y,width,height
		jFrame.add(jTextFieldPassword);

		jButtonLogin = new JButton("Login");
		jButtonLogin.setBounds(100, 220, 400, 50);
		jButtonLogin.addActionListener(this);
		jFrame.add(jButtonLogin);
		
	}
	
	public Vector<String> setupBranches() {
		
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		String DB_URL = "jdbc:mysql://localhost:3306/scmdb?autoReconnect=true&useSSL=false";
		String USERNAME = "root";
		String PASSWORD = "root@123";
		

		Vector<String> branches = new Vector<String>();
		
		//sql statement
		String sql = "select manufcturer_ID, Branch_ID from manudata";
		
		try {
			
			//Open Connections
			Class.forName(JDBC_DRIVER);
			Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			Statement stmt = conn.createStatement();
			
			//Execute the query
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				int manufacturerID = rs.getInt("manufacturer_ID");
				String BranchID = rs.getString("Branch_ID");
				branches.add(Integer.toString(manufacturerID)+" - "+BranchID);
			}

			//Close Connections
			rs.close();
			stmt.close();
			conn.close();
			
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return branches;
		
	}
	
	
	public void selectBranch(Vector<String> branches) {
		
		jFrame = new JFrame();
		jFrame.setSize(1500,1500);
		jFrame.setTitle("Select Manufacturer");
		jFrame.setLayout(null);  
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		jButtonBack = new JButton("<");
		jButtonBack.setBounds(10, 10, 50, 50);
		jButtonBack.addActionListener(this);
		jFrame.add(jButtonBack);
		
		jRadioButtons = new JRadioButton[branches.size()];
		buttonGroup = new ButtonGroup();
		
		int y_coordinate=100;
		for(int index=0;index<branches.size();index++, y_coordinate+=60) {
			
			String label = branches.get(index);

			jRadioButtons[index]=new JRadioButton(label);
			jRadioButtons[index].setBounds(100, y_coordinate, 200, 50);
			buttonGroup.add(jRadioButtons[index]);
			jFrame.add(jRadioButtons[index]);
			
		}
		
		jButtonOrder = new JButton("Order");
		jButtonOrder.setBounds(100, y_coordinate, 400, 50);
		jButtonOrder.addActionListener(this);
		jFrame.add(jButtonOrder);
		
	}
	
	public static void main(String args[]) {
		CustomerLoginGUI loginToDonateGUI = new CustomerLoginGUI();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		//Select Branch
		if(jRadioButtons!=null) {
			for(int index=0;index<jRadioButtons.length;index++) {
				if(jRadioButtons[index].isSelected()) {
					selectedBranchIndex = index;
				}
			}
		}
		

		//Back Button
		if(e.getSource()==jButtonBack) {
			jFrame.dispose();
			MainMenuGUI mainMenuGUI = new MainMenuGUI();
		}
		
		if(e.getSource()==jButtonBack2) {
			jFrame.dispose();
			loginAsCustomer();
		}
		
		if(e.getSource()==jButtonOrder) {
			//updateDatabase();
			JOptionPane.showMessageDialog(jFrame, "Ordered Successfully");
			jFrame.dispose();
			MainMenuGUI mainMenuGUI = new MainMenuGUI();
		}
		
		//Login Customer Button
		if(e.getSource()==jButtonLogin) {
			
			String username = jTextFieldUsername.getText();
			String password = jTextFieldPassword.getText();
			
			email = fetchCredentials(username,password);

			//Not registered
			if(email=="") {
				JOptionPane.showMessageDialog(jFrame, "Customer not registered!");
				return;
			}
			//Incorrect Password
			else if(!password.equals(passwordFromDB)) {
				JOptionPane.showMessageDialog(jFrame, "Incorrect Password!");
				return;
			}
			else {
				jFrame.dispose();
				selectBranch(setupBranches());
			}
			
		}
		
	}
	
	public String fetchCredentials(String username, String password) {
		
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		String DB_URL = "jdbc:mysql://localhost:3306/scmdb?autoReconnect=true&useSSL=false";
		String USERNAME = "root";
		String PASSWORD = "root@123";
		
		String email = "";
			
		try {
			
			//Open Connections
			Class.forName(JDBC_DRIVER);
			Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			Statement stmt = conn.createStatement();
			ResultSet rs = null;
			
			email = "";
			passwordFromDB = "";

			//Execute the query
			String sql = "SELECT Email, Password, Gender from customer WHERE Username = '"+username+"'";
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				email = rs.getString("Email");
				passwordFromDB = rs.getString("Password");
				gender = rs.getString("Gender");
			}

			//Close Connections
			rs.close();
			stmt.close();
			conn.close();
			
			
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return email;
		
	}

}