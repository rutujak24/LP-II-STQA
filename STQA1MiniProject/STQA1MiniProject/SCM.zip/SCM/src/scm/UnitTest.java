package scm;

import static org.junit.Assert.*;
import org.junit.Test;

public class UnitTest {

	@Test
	public void testName() {
		Validator obj1 = new Validator();
		boolean output_f = Validator.name("Sushmita");
		
		//Test the output
		assertEquals(true, output_f);
	}
	
	@Test
	public void testGender() {
		Validator obj1 = new Validator();
		boolean output_f = Validator.gender("F");
		
		//Test the output
		assertEquals(true, output_f);
	}

	@Test
	public void testYesorno() {
		Validator obj1 = new Validator();
		boolean output_f = Validator.yesorno('Y');
		
		//Test the output
		assertEquals(true, output_f);
	}
	
	@Test
	public void testUsername() {
		Validator obj1 = new Validator();
		boolean output_f = Validator.username("abcxyz");
		
		//Test the output
		assertEquals(true, output_f);
	}
	
	@Test
	public void testPhoneNumber() {
		Validator obj1 = new Validator();
		boolean output_f = obj1.phone_number("9123412345");
		
		//Test the output
		assertEquals(true, output_f);
	}
	
	@Test
	public void testAadharNumber() {
		Validator obj1 = new Validator();
		boolean output_f = obj1.aadhar_number("2123 4123 4532");
		
		//Test the output
		assertEquals(true, output_f);
	}
	
	@Test
	public void testEmailID() {
		Validator obj1 = new Validator();
		boolean output_f = obj1.email_id("abc@gmail.com");
		
		//Test the output
		assertEquals(true, output_f);
	}
	
	@Test
	public void testPassword() {
		Validator obj1 = new Validator();
		boolean output_f = obj1.password("Abc@1234");
		
		//Test the output
		assertEquals(true, output_f);
	}
	
	@Test
	public void testPasswordAgain() {
		Validator obj1 = new Validator();
		boolean output_f = obj1.passwordAgain("Abc@1234", "Abc@1234");
		
		//Test the output
		assertEquals(true, output_f);
	}
	
	@Test
	public void testFetchCustomerCredentials() {
		CustomerLoginGUI obj1 = new CustomerLoginGUI();
		String output_f = obj1.fetchCredentials("xyzabc", "Abcd@123");
		
		//Test the output
		assertEquals("xyz@gmail.com", output_f);
	}

}
