package scm;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class MainMenuGUI implements ActionListener {

	JFrame jFrame;
	
	String[] labels = {
		"Register Manufacturer","Register Customer","Customer Login to Order","Exit"
	};
	
	JButton[] jButtons;
	
	MainMenuGUI(){
		
		//Set up jframe
		jFrame = new JFrame();
		jFrame.setSize(1100,1100);
		jFrame.setTitle("Supply Chain Management System");
		jFrame.setLayout(null);  
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//Set up buttons
		jButtons = new JButton[labels.length];
		for(int index=0, y_coordinate=100;index<labels.length; index++, y_coordinate+=60) {
			String label = labels[index];
			jButtons[index]=new JButton(label);
			jButtons[index].setBounds(100, y_coordinate, 300, 50);
			jButtons[index].addActionListener(this);
			jFrame.add(jButtons[index]);
		}
		
	}
	
	public static void main(String args[]) {
		MainMenuGUI mainMenuGUI = new MainMenuGUI();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		//Register Manufacturer Button
		if(e.getSource()==jButtons[0]) {
			jFrame.dispose();
			RegisterManufacturerGUI registerManufacturerGUI = new RegisterManufacturerGUI();
		}
		
		//Register Customer Button
		if(e.getSource()==jButtons[1]) {
			jFrame.dispose();
			RegisterCustomerGUI registerCustomerGUI = new RegisterCustomerGUI();
		}
		
		//Login To Order Item Button
		if(e.getSource()==jButtons[2]) {
			jFrame.dispose();
			CustomerLoginGUI loginToOrderGUI = new CustomerLoginGUI();
		}
		
		//Exit Button
		if(e.getSource()==jButtons[4]) {
			jFrame.dispose();
		}
		
	}

}
