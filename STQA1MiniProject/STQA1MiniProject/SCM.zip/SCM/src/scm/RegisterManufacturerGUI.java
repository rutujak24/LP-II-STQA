package scm;

import javax.swing.*;

import java.awt.FlowLayout;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Vector;
import javax.swing.JScrollPane;

public class RegisterManufacturerGUI implements ActionListener, FocusListener {
	
	//member variables
	String[] labels = {
		"First Name","Last Name","Aadhar Card","Phone Number","Email ID","Address","Supplier ID"
	};
	
	String[] genders = {"M","F","O"};
	
	JFrame jFrame;
	JTextField jFirstName, jLastName, jAadharCard, jPhoneNumber, jEmailID, jAddress; 
	JComboBox jSupplierID;
	JButton jButtonBack, jButtonRegister;
	JPanel controlPanel;
	
	int length = labels.length;
	
	int validatedFieldsCount;
	boolean[] validatedBuffer;
	
	//default constructor
	RegisterManufacturerGUI(){
		
		//Validated Fields Checking Setup
		validatedFieldsCount=0;
		validatedBuffer = new boolean[length];
		
		//Fields Setup
		jFirstName = new JTextField(); 
		jLastName = new JTextField(); 
		jAadharCard = new JTextField(); 
		jPhoneNumber = new JTextField();
		jEmailID = new JTextField(); 
		jAddress = new JTextField();
		jSupplierID = new JComboBox(setupBranches());
		
		//adding Listeners to all the fields
		jFirstName.addFocusListener(this);
		jLastName.addFocusListener(this);
		jAadharCard.addFocusListener(this);
		jPhoneNumber.addFocusListener(this);
		jEmailID.addFocusListener(this);
		jAddress.addFocusListener(this);
		jSupplierID.addActionListener(this);
		
		//Array of fields (Iterate through setting up Jframe)
		JComponent[] fieldComponents = {
			jFirstName,jLastName,jAadharCard,jPhoneNumber,
			jEmailID,jAddress,jSupplierID,
		};
		
		//Setting up JFrame
		jFrame = new JFrame();
		jFrame.setSize(1500,1500);
		jFrame.setTitle("Register Manufacturer GUI");
		jFrame.setLayout(null);  
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//Back Button
		jButtonBack = new JButton("<");
		jButtonBack.setBounds(10, 10, 50, 50);
		jButtonBack.addActionListener(this);
		jFrame.add(jButtonBack);

		int y_coordinate = 40;
		for(int index=0;index<length;index++) {

			//Setup the Label of the Field
			JLabel jLabel=new JLabel(labels[index]);
			jLabel.setBounds(100, y_coordinate, 200, 30);
			jFrame.add(jLabel);
			
			//Setup the field itself
			fieldComponents[index].setBounds(300, y_coordinate, 200, 30); //x,y,width,height
			jFrame.add(fieldComponents[index]);

			y_coordinate+=40;
				
		}

		//Register Button
		jButtonRegister = new JButton("Register");
		jButtonRegister.setBounds(100, y_coordinate, 400, 50);
		jButtonRegister.addActionListener(this);
		jButtonRegister.setEnabled(false);
		jFrame.add(jButtonRegister);
		
		controlPanel = new JPanel();
	    controlPanel.setLayout(new FlowLayout());
	    jFrame.add(controlPanel);
		
		
	}
	
	public static void main(String args[]) {
		RegisterManufacturerGUI registerManufacturerGUI = new RegisterManufacturerGUI();
		registerManufacturerGUI.showScrollPaneDemo();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		

		//Back Button
		if(e.getSource()==jButtonBack) {
			jFrame.dispose();
			MainMenuGUI mainMenuGUI = new MainMenuGUI();
		}
		
		//Register Button
		if(e.getSource()==jButtonRegister) {
			updateDatabase();
			JOptionPane.showMessageDialog(jFrame, "Manufacturer Registered Successfully!");
			jFrame.dispose();
			MainMenuGUI mainMenuGUI = new MainMenuGUI();
		}
		
		//Branch Drop Down Selected
		if(e.getSource()==jSupplierID) {
			if(validatedBuffer[5]==false) {
				validatedBuffer[5] = true;
				validatedFieldsCount++;
			}
			checkRegisterButton();
		}
		
	}

	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
	}
	
	public void checkRegisterButton() {
		jButtonRegister.setEnabled(validatedFieldsCount==length);
	}

	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		
		//First Name
		if(e.getSource()==jFirstName){
			if(!Validator.name(jFirstName.getText())) {
				if(validatedBuffer[0]==true) {
					validatedBuffer[0]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "First Name cannot be empty");
			}
			else {
				if(validatedBuffer[0]==false) {
					validatedBuffer[0]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}	
		
		//Last Name
		if(e.getSource()==jLastName){
			if(!Validator.name(jLastName.getText())) {
				if(validatedBuffer[1]==true) {
					validatedBuffer[1]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Last Name cannot be empty");
			}
			else {
				if(validatedBuffer[1]==false) {
					validatedBuffer[1]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}	
		
		//Aadhar Card
		if(e.getSource()==jAadharCard){
			if(!Validator.aadhar_number(jAadharCard.getText())) {
				if(validatedBuffer[2]==true) {
					validatedBuffer[2]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Invalid Aadhar Card");
			}
			else {
				if(validatedBuffer[2]==false) {
					validatedBuffer[2]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}
		
		//Phone Number
		if(e.getSource()==jPhoneNumber){
			if(!Validator.phone_number(jPhoneNumber.getText())) {
				if(validatedBuffer[3]==true) {
					validatedBuffer[3]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Phone Number needs to be a 10-digit number");
			}
			else {
				if(validatedBuffer[3]==false) {
					validatedBuffer[3]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}
		
		//Email
		if(e.getSource()==jEmailID){
			if(!Validator.email_id(jEmailID.getText())) {
				if(validatedBuffer[4]==true) {
					validatedBuffer[4]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Enter a valid Email Address");
			}
			else {
				if(validatedBuffer[4]==false) {
					validatedBuffer[4]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}	
		
		//Address
		if(e.getSource()==jAddress){
			if(!Validator.name(jAddress.getText())) {
				if(validatedBuffer[6]==true) {
					validatedBuffer[6]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Address cannot be empty");
			}
			else {
				if(validatedBuffer[6]==false) {
					validatedBuffer[6]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}
		
	}
	
	public void updateDatabase() {
		
		String firstName = jFirstName.getText();
		String lastName = jLastName.getText();
		String aadharCard = jAadharCard.getText();
		String phoneNumber = jPhoneNumber.getText();
		String emailID = jEmailID.getText();
		String address = jAddress.getText();
		String supplierID = (String) jSupplierID.getSelectedItem();
		supplierID = supplierID.substring(0, 4);
		String isAvailable = "1";

		LocalDate today = LocalDate.now();
		String date = "STR_TO_DATE('"+today.getDayOfMonth()+"-"+today.getMonthValue()+"-"+today.getYear()+"', '%d-%m-%Y')";
				
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		String DB_URL = "jdbc:mysql://localhost:3306/scmdb?autoReconnect=true&useSSL=false";
		String USERNAME = "root";
		String PASSWORD = "root@123";
		
		String sql = "INSERT INTO manufacturer VALUES ( '"+firstName+"', '"+lastName+"' , '"+aadharCard+"' , '"+phoneNumber+"' , '"+emailID+"' , '"+address+"' ,'"+supplierID+"', "+isAvailable+" )";

		try {
			
			//Open Connections
			Class.forName(JDBC_DRIVER);
			Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			Statement stmt = conn.createStatement();
			
			//Execute the query
			stmt.executeUpdate(sql);

			//Close Connections
			stmt.close();
			conn.close();
			
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
	public Vector<String> setupBranches() {
		
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		String DB_URL = "jdbc:mysql://localhost:3306/scmdb?autoReconnect=true&useSSL=false";
		String USERNAME = "root";
		String PASSWORD = "root@123";
		

		Vector<String> branches = new Vector<String>();
		
		//sql statement
		String sql = "select supplier_ID, Branch_ID from suppdata";
		
		try {
			
			//Open Connections
			Class.forName(JDBC_DRIVER);
			Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			Statement stmt = conn.createStatement();
			
			//Execute the query
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				int supplierID = rs.getInt("supplier_ID");
				String BranchID = rs.getString("Branch_ID");
				branches.add(Integer.toString(supplierID)+" - "+BranchID);
			}

			//Close Connections
			rs.close();
			stmt.close();
			conn.close();
			
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return branches;
		
		
		
	}
	private JTextArea outputTextArea;
	
	private void showScrollPaneDemo() {
	      outputTextArea = new JTextArea("",5,20);
	      JScrollPane scrollPane = new JScrollPane(outputTextArea);    
	      scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	      controlPanel.add(scrollPane);
	      jFrame.setVisible(true);  
	   }   

}
