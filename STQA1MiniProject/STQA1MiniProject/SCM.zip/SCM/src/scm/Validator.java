package scm;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {

	
	public static boolean name(String name) {
		if (name.equals(""))
			return false;
		return true;
	}
	
	public static boolean gender(String g) {
		if (g.equals("M")||g.equals("F")||g.equals("O"))
			return true;
		return false;
	}
	
	public static boolean yesorno(char yn) {
		switch(yn) {
			case 'Y':
			case 'N':
			case 'y':
			case 'n':
				return true;
			default:
				return false;
		}
	}
	
	public static boolean username(String username) {
		if (username.equals(""))
			return false;
		return true;
	}
	
	public static boolean phone_number(String phoneNumber) {
		
		try {
			long phno = Long.parseLong(phoneNumber);
			int digits = (int) java.lang.Math.log10(phno) + 1;
			int first_digit = (int) (phno/1000000000);
			if(digits==10 && first_digit>=7 && first_digit<=9)
				return true;
			else if(digits==12 && first_digit>=917 && first_digit<=919)
				return true;
			return false;
		}
		catch(Exception e) {
			return false;
		}
	}
	
	public static boolean aadhar_number(String aadharNumber) {
        //Regex to check valid Aadhar number
        String regex = "^[2-9]{1}[0-9]{3}\\s[0-9]{4}\\s[0-9]{4}$";
 
        //Compile the ReGex
        Pattern p = Pattern.compile(regex);
 
        //If the string is empty
        //return false
        if (aadharNumber == null) {
            return false;
        }
        //Pattern class contains matcher() method
        //to find matching between given string
        //and regular expression
        Matcher m = p.matcher(aadharNumber);
 
        //Return if the string
        //matched the ReGex
        return m.matches();
     }
	
	public static boolean email_id(String e) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+"[a-zA-Z0-9_+&*-]+)*@"+"(?:[a-zA-Z0-9-]+\\.)+[a-z"+"A-Z]{2,7}$"; 
        Pattern pat = Pattern.compile(emailRegex); 
        if (e==null) 
        	return false; 
        return pat.matcher(e).matches(); 
	}
	
	public static boolean password(String password) {
		//Password Must have atleast 8 characters
		//Password must have an uppercase, a lowercase, a special character and a digit
		Pattern ptr = Pattern.compile("^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*()_+,.\\\\\\/;':\"-]).{8,}$");
		return ptr.matcher(password).matches();
	}
	
	public static boolean passwordAgain(String password, String password2) {
		return password.equals(password2);
	}
	
	public static void main(String args[]) {
		System.out.println("Validation Class");
		System.out.println(aadhar_number("3675 9834 6015"));
		System.out.println(email_id("abcxyz@gmail.com"));
	}

}