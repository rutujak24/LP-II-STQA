package scm;

import javax.swing.*;

import java.awt.event.*;
import java.sql.*;


public class RegisterCustomerGUI implements ActionListener, FocusListener {
	
	//member variables
	String[] labels = {
		"First Name","Last Name","Username","Gender","Email","Address","Phone Number","Password","Password Again"	
	};
	
	String[] genders = {"M","F","O"};
	
	JFrame jFrame;
	JTextField jFirstName, jLastName, jUsername, jEmail, jAddress,  jPhoneNumber, jPassword, jPassword2; 
	JComboBox jGender;
	JButton jButtonBack, jButtonRegister;
	
	int length = labels.length;
	
	int validatedFieldsCount;
	boolean[] validatedBuffer;
	
	//default constructor
	RegisterCustomerGUI(){
		
		//Validated Fields Checking Setup
		validatedFieldsCount=0;
		validatedBuffer = new boolean[length];
		
		//Fields Setup
		jFirstName = new JTextField(); 
		jLastName = new JTextField(); 
		jUsername = new JTextField(); 
		jGender = new JComboBox(genders);
		jEmail = new JTextField(); 
		jAddress = new JTextField();
		jPhoneNumber = new JTextField();
		jPassword = new JTextField(); 
		jPassword2 = new JTextField();
		
		//adding Listeners to all the fields
		jFirstName.addFocusListener(this);
		jLastName.addFocusListener(this);
		jUsername.addFocusListener(this);
		jGender.addActionListener(this);
		jEmail.addFocusListener(this);
		jAddress.addFocusListener(this);
		jPhoneNumber.addFocusListener(this);
		jPassword.addFocusListener(this);
		jPassword2.addFocusListener(this);
		
		//Array of fields (Iterate through setting up Jframe)
		JComponent[] fieldComponents = {
			jFirstName,jLastName,jUsername,jGender,jEmail,jAddress,jPhoneNumber,jPassword,jPassword2,
		};
		
		//Setting up JFrame
		jFrame = new JFrame();
		jFrame.setSize(1500,1500);
		jFrame.setTitle("Register Customer GUI");
		jFrame.setLayout(null);  
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//Back Button
		jButtonBack = new JButton("<");
		jButtonBack.setBounds(10, 10, 50, 50);
		jButtonBack.addActionListener(this);
		jFrame.add(jButtonBack);

		int y_coordinate = 40;
		for(int index=0;index<length;index++) {

			//Setup the Label of the Field
			JLabel jLabel=new JLabel(labels[index]);
			jLabel.setBounds(100, y_coordinate, 200, 40);
			jFrame.add(jLabel);
			
			//Setup the field itself
			fieldComponents[index].setBounds(300, y_coordinate, 200, 40); //x,y,width,height
			jFrame.add(fieldComponents[index]);

			y_coordinate+=40;
				
		}

		//Register Button
		jButtonRegister = new JButton("Register");
		jButtonRegister.setBounds(100, y_coordinate, 400, 50);
		jButtonRegister.addActionListener(this);
		jButtonRegister.setEnabled(false);
		jFrame.add(jButtonRegister);
		
		
	}
	
	public static void main(String args[]) {
		RegisterCustomerGUI registerCustomerGUI = new RegisterCustomerGUI();
	}
	
	
	public void checkRegisterButton() {
		jButtonRegister.setEnabled(validatedFieldsCount==length);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		

		//Back Button
		if(e.getSource()==jButtonBack) {
			jFrame.dispose();
			MainMenuGUI mainMenuGUI = new MainMenuGUI();
		}
		
		//Register Button
		if(e.getSource()==jButtonRegister) {
			updateDatabase();
			JOptionPane.showMessageDialog(jFrame, "Customer Registered Successfully!");
			jFrame.dispose();
			MainMenuGUI mainMenuGUI = new MainMenuGUI();
		}
		
		//Gender Drop Down Selected
		if(e.getSource()==jGender) {
			if(validatedBuffer[3]==false) {
				validatedBuffer[3] = true;
				validatedFieldsCount++;
			}
			checkRegisterButton();
		}
		
	}

	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		
		//First Name
		if(e.getSource()==jFirstName){
			if(!Validator.name(jFirstName.getText())) {
				if(validatedBuffer[0]==true) {
					validatedBuffer[0]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "First Name cannot be empty");
			}
			else {
				if(validatedBuffer[0]==false) {
					validatedBuffer[0]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}	
		
		//Last Name
		if(e.getSource()==jLastName){
			if(!Validator.name(jLastName.getText())) {
				if(validatedBuffer[1]==true) {
					validatedBuffer[1]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Last Name cannot be empty");
			}
			else {
				if(validatedBuffer[1]==false) {
					validatedBuffer[1]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}	
		
		//Username
		if(e.getSource()==jUsername){
			if(!Validator.username(jUsername.getText())) {
				if(validatedBuffer[2]==true) {
					validatedBuffer[2]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Username cannot be empty");
			}
			else {
				if(validatedBuffer[2]==false) {
					validatedBuffer[2]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}
		
		//Email
				if(e.getSource()==jEmail){
					if(!Validator.email_id(jEmail.getText())) {
						if(validatedBuffer[4]==true) {
							validatedBuffer[4]=false;
							validatedFieldsCount--;
						}
						JOptionPane.showMessageDialog(jFrame, "Enter a valid Email Address");
					}
					else {
						if(validatedBuffer[4]==false) {
							validatedBuffer[4]=true;
							validatedFieldsCount++;
						}
						checkRegisterButton();
					}
				}	
				
				
				
				//Address
				if(e.getSource()==jAddress){
					if(!Validator.name(jAddress.getText())) {
						if(validatedBuffer[5]==true) {
							validatedBuffer[5]=false;
							validatedFieldsCount--;
						}
						JOptionPane.showMessageDialog(jFrame, "Address cannot be empty");
					}
					else {
						if(validatedBuffer[5]==false) {
							validatedBuffer[5]=true;
							validatedFieldsCount++;
						}
						checkRegisterButton();
					}
				}
		
		//Phone Number
		if(e.getSource()==jPhoneNumber){
			if(!Validator.phone_number(jPhoneNumber.getText())) {
				if(validatedBuffer[6]==true) {
					validatedBuffer[6]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Phone Number needs to be a 10-digit number");
			}
			else {
				if(validatedBuffer[6]==false) {
					validatedBuffer[6]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}
		
		//Password
		if(e.getSource()==jPassword){
			if(!Validator.password(jPassword.getText())) {
				if(validatedBuffer[7]==true) {
					validatedBuffer[7]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Password should have atleast 8 characters, which must include an uppercase character, a lowercase character, a numerical digit and a special character.");
			}
			else {
				if(validatedBuffer[7]==false) {
					validatedBuffer[7]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}	
		
		//Password Again
		if(e.getSource()==jPassword2){
			if(!Validator.passwordAgain(jPassword.getText(),jPassword2.getText())) {
				if(validatedBuffer[8]==true) {
					validatedBuffer[8]=false;
					validatedFieldsCount--;
				}
				JOptionPane.showMessageDialog(jFrame, "Password must be same as above");
			}
			else {
				if(validatedBuffer[8]==false) {
					validatedBuffer[8]=true;
					validatedFieldsCount++;
				}
				checkRegisterButton();
			}
		}	
		
	}
	
	public boolean updateDatabase() {
		
		//Field Variables (Already Validated)
		String firstName = jFirstName.getText();
		String lastName = jLastName.getText();
		String username = jUsername.getText();
		String gender = (String) jGender.getSelectedItem();
		String email = jEmail.getText();
		String address = jAddress.getText();
		String phoneNumber = jPhoneNumber.getText();
		String password = jPassword.getText();
		
		//JDBC Variables
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		String DB_URL = "jdbc:mysql://localhost:3306/scmdb?autoReconnect=true&useSSL=false";
		String USERNAME = "root";
		String PASSWORD = "root@123";
		
		//SQL Query
		String sql = "INSERT INTO customer VALUES ( '"+firstName+"' , '"+lastName+"' , '"+username+"' , '"+gender+"' , '"+email+"', '"+address+"','"+phoneNumber+"' , '"+password+"' )";

		try {
			
			//Open Connections
			Class.forName(JDBC_DRIVER);
			Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			Statement stmt = conn.createStatement();
			
			//Execute the query
			stmt.executeUpdate(sql);

			//Close Connections
			stmt.close();
			conn.close();
			
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return true;
	}

}
